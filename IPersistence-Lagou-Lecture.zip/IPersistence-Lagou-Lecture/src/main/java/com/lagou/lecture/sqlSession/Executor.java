package com.lagou.lecture.sqlSession;

import com.lagou.lecture.pojo.Configuration;
import com.lagou.lecture.pojo.MappedStatement;

import java.util.List;

public interface Executor {

    public <E> List<E> query(Configuration configuration, MappedStatement mappedStatement, Object... params) throws Exception;

    public int update(Configuration configuration, MappedStatement mappedStatement, Object... params) throws Exception;

    public int delete(Configuration configuration, MappedStatement mappedStatement, Object... params) throws Exception;
}
