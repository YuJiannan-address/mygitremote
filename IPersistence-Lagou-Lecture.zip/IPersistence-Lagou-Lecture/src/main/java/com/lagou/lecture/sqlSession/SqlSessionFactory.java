package com.lagou.lecture.sqlSession;

public interface SqlSessionFactory {

    public SqlSession openSession();


}
