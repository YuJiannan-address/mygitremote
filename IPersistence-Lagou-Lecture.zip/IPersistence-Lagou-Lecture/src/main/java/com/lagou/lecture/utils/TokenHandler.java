
package com.lagou.lecture.utils;

public interface TokenHandler {
  String handleToken(String content);
}

